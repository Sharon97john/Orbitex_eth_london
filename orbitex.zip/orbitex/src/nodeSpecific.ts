import { Buffer } from "buffer";

globalThis.Buffer = Buffer;
