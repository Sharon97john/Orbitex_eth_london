## Tezos-Lottery

## Quick Start

### 1. Clone the Repository

```
$ git clone https://github.com/abhi1506manu/tezos-lottery.git
```

### 2. Install Dependencies
```
$ cd tezos-lottery
$ npm install
```

### 3. To Start 

```
$ npm run dev
```

## NFT Contracts

Ghostnet contract : KT1WT6AjrzNhUqXZgc2JVE8bvRgb9WmkUXrT

RPC URL : https://ghostnet.smartpy.io
